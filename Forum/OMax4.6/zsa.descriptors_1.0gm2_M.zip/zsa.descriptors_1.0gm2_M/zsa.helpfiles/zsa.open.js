function loadbang()
{
    outlet(0, this.patcher.parentpatcher.name);
}